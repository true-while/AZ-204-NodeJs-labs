const appInsights = require('applicationinsights');

appInsights.setup(process.env.APPINSIGHTS_INSTRUMENTATIONKEY).setInternalLogging(true, true).start(); 

const express = require("express");
const forecast = require("./forecast");

const app = express();
const bodyparser = require("body-parser");

const port = process.env.PORT || 3000;

app.use(bodyparser.json());
app.use(bodyparser.urlencoded({ extended: false }));

app.get("/", (req, res) => {
    res.status(200).send();
});

app.get("/weatherforecast", (req, res) => {
    res.status(200).send(forecast.getForecast());
});

app.listen(port, () => {
  console.log(`running at port ${port}`);
});